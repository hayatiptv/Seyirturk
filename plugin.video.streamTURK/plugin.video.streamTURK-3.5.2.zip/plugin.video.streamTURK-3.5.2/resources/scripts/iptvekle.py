# -*- coding: utf-8 -*-
import sys
import urllib,urllib2
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import json, base64
import hashlib
import os.path
import time
from xml.dom import minidom

settings = xbmcaddon.Addon(id='plugin.video.streamTURK')
userdata = xbmc.translatePath('special://userdata')

def showMessage(heading='streamTURK', message = '', times = 2000, pics = ''):
    try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
    except Exception, e:
        xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )
def Url_Al(url, mac = None):
    sign = '?'
    url = url.strip(' \t\n\r')
    req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 streamTURK_KODI Kodi',settings.getSetting("key"): settings.getSetting("answer"), 'Connection': 'Close'})
    page = urllib2.urlopen(req).read()
    return page
user_id = settings.getSetting('user_id')
root = settings.getSetting('root')

if user_id != "":
    try:
        image = re.findall('image=(.*?)&',sys.argv[1])[0]
    except:
        image = ""
    try:
        link = re.findall('link=(.*?)&',sys.argv[1])[0]
    except:
        link = ""
    try:
        name = re.findall('name=(.*?)$',sys.argv[1])[0]
        name = name.replace('[COLOR blue][B][COLOR red]» [/COLOR]','').replace('[/B][/COLOR]','').replace(' ','%20')
    except:
        name ='noname'
    add = Url_Al(root + 'user.php?type=faviptv&u_id=' + user_id + '&do=0&link=' + link + '&name=' + name + '&image=' + image )
    if int(add) == 0:
        showMessage('streamTURK','[COLOR orange][B]IPTV eklendi.[/B][/COLOR]', 3000,xbmc.translatePath('special://home/addons/plugin.video.streamTURK/resources/media/plus.png'))
    else :
        showMessage('streamTURK','[COLOR orange][B]IPTV zaten var.[/B][/COLOR]', 3000, xbmc.translatePath('special://home/addons/plugin.video.streamTURK/resources/media/unlem.png'))    
else:
    showMessage('streamTURK','[COLOR orange][B]Giriş yapmamışsınız.[/B][/COLOR]',3000, xbmc.translatePath('special://home/addons/plugin.video.streamTURK/resources/media/x.png'))

