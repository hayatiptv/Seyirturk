# -*- coding: utf-8 -*-
import urllib, urllib2, base64, sys, os, json
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc

settings = xbmcaddon.Addon(id='plugin.video.seyirTURK')
def showMessage(heading='seyirTURK', message = '', times = 2000, pics = ''):
                try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
                except Exception, e:
                        xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )

def decode_base64(data):
    missing_padding = len(data) % 4
    if missing_padding != 0:
        data += b'='* (4 - missing_padding)
    return base64.decodestring(data)

def get_url(url):
    req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 seyirTURK__KODI', settings.getSetting("key"): settings.getSetting("answer"), 'Connection': 'Close'})
    page = urllib2.urlopen(req).read()
    return page

def get_html(url):
    import cookielib
    cookie_handler = urllib2.HTTPCookieProcessor(cookielib.LWPCookieJar())
    opener = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())
    opener = urllib2.install_opener(opener)
    request = urllib2.Request(url, None)
    request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0')
    response = urllib2.urlopen(request, timeout=10)
    result = response.read() + 'kuki :' + str(response.headers.get('Set-Cookie'))
    response.close()
    return result

def parse(url):
    if 'ok.ru/videoembed' in url or 'odnoklassniki.ru' in url:
            url= okru(url)
    elif "vidmoly" in url or "flmplayer" in url:
            url = vidmoly(url)
    elif "closeload" in url:
            url= closeload(url)
    elif "afaki" in url or '24detv' in url or 'ozeltv1' in url or 'sporizle1' in url:
            url= afaki(url)
    elif "canlitvlive" in url:
            url= canlitvlive(url)
    elif "uptostream" in url:
            url= uptostream(url)
    elif "trttv" in url:
            url= url
    elif "youtube" in url:
            url= youtube(url)
    elif "filmmodu" in url:
            url= filmmodu(url)
    elif "mail.ru" in url:
            url= mailru(url)
    elif "fembed" in url or 'feurl' in url or 'vcdn' in url:
            url= fembed(url)
    elif "imdb" in url:
            url= imdb(url)
    elif "s1cdn" in url:
            url= s1cdn(url)
    elif "showtv.com" in url or 'showturk.com.tr' in url or 'showmax.com.tr' in url:
            url= show(url)
    elif "yjco.xyz" in url:
            url= yjco(url) 
    elif "foxplay.com" in url or 'fox' in url:
            url= foxplay(url)
    elif "startv.com" in url:
            url= startv(url)
    elif 'ahaber.com.tr' in url or 'apara' in url or 'anews.com.tr' in url or 'aspor.com.tr' in url or 'a2tv' in url:
            url= ahaber(url)
    elif 'atv.com.tr' in url or 'atv.json' in url:
            url= atv(url)
    elif 'dailymotion' in url:
            url= dailymotion(url)
    elif 'fileru' in url:
            url = fileru(url)
    elif 'plus/iframe.php' in url:
            url= plus(url)
    elif 'supervideo.tv' in url:
            url= supervideo(url)
    elif 'kanald.com' in url or 'kanald.json' in url:
            url= kanald(url)
    elif 'dizibox' in url:
            url= dizibox(url)
    elif 'dizilabapi.com' in url:
            url= dizilabapi(url)
    elif 'chefkoch24.eu' in url:
            url= chefkoch24(url)
    elif 'haberturk.com' in url or 'bloomberght.com' in url:
            url= haberturk(url)
    elif 'dha.com' in url:
            url= dha(url)
    elif 'tv8.com.tr' in url:
            url= tv8(url)
    elif 'tlctv.com' in url or 'dmax.com' in url:
            url= tlc(url)
    elif 'ntv.com.tr' in url and 'womantv' not in url:
            url= ntv(url)
    elif 'videobin.co' in url:
            url= videobin(url)
    elif 'gounlimited.to' in url:
            url= gounlimited(url)
    elif 'saruch.co' in url:
            url= saruch(url)
    elif 'yabancidizi.vip' in url:
            url= yabancidizi(url)
    elif 'streamtheworld.com' in url:
            url= streamtheworld(url)
    elif 'chaturbate.com' in url:
            url= chaturbate(url)
    elif 'hdtvler.tv' in url:
            url= hdtvler(url)
    elif 'cnnturk.com' in url or 'teve2.com.tr' in url:
            url= cnnteve2(url)
    elif 'kanal7.com' in url:
            url= kanal7(url)
    elif 'halktv.com.tr' in url or 'tv100.com' in url:
            url= halktv(url)
    elif 'kralmuzik.com.tr' in url:
            url= kralmuzik(url)
    elif 'numberone.com.tr' in url:
            url= numberone(url)
    elif 'brtk.net' in url:
            url= brtk(url)
    elif 'tv360.com.tr' in url or 'm.star.com.tr/video/canli.asp' in url:
            url= tv360(url)
    elif 'ucankus.com' in url:
            url= ucankus(url)
    elif 'dreamturk.com.tr' in url:
            url= dreamturk(url)
    elif 'beyaztv.com.tr' in url:
            url= beyaztv(url)
    elif 'tvem.com.tr' in url:
            url= tvem(url)
    elif 'ulusal.com.tr' in url:
            url= ulusal(url)
    elif 'kanalb.com.tr' in url:
            url= kanalb(url)
    elif 'tvnet.com.tr' in url:
            url= tvnet(url)
    elif 'ulketv.com.tr' in url:
            url= ulketv(url)
    elif 'ekoturk.com' in url:
            url= ekoturk(url)
    elif 'womantv.com.tr' in url:
            url= womantv(url)
    elif 'sportstv.com.tr' in url:
            url= sportstv(url)
    elif 'tjk.org' in url:
            url= tjk(url)
    elif 'yabantv.com' in url or 'koytv.tv' in url:
            url= yaban(url)
    elif 'canliradyolar.org' in url:
            url= canliradyolar(url)
    elif 'ashemaletube.com' in url:
            url= ashemale(url)
    elif 'pornhub.com' in url:
            url= pornhub(url)
    elif 'clipwatching.com' in url:
            url= clipwatching(url)
    elif 'xvideos.com' in url:
            url= xvideos(url)
    else:
        url = url
    if 'dailymotion.com/embed' in url or 'youtube.com/watch' in url or ('gounlimited' in url and 'v.mp4' not in url) or ("vidmoly" in url and 'Referer' not in url) or ("odnoklassniki.ru" in url and 'Referer' not in url) or ("ok.ru" in url and 'Referer' not in url):
        url = parse(url)
    return url


def youtube(url):
    gecerli_url = '^\n                 (\n                     (?:https?://)?                                       # http(s):// (optional)\n                     (?:youtu\\.be/|(?:\\w+\\.)?youtube(?:-nocookie)?\\.com/|\n                        tube\\.majestyc\\.net/)                             # the various hostnames, with wildcard subdomains\n                     (?:.*?\\#/)?                                          # handle anchor (#/) redirect urls\n                     (?!view_play_list|my_playlists|artist|playlist)      # ignore playlist URLs\n                     (?:                                                  # the various things that can precede the ID:\n                         (?:(?:v|embed|e)/)                               # v/ or embed/ or e/\n                         |(?:                                             # or the v= param in all its forms\n                             (?:watch(?:_popup)?(?:\\.php)?)?              # preceding watch(_popup|.php) or nothing (like /?v=xxxx)\n                             (?:\\?|\\#!?)                                  # the params delimiter ? or # or #!\n                             (?:.*?&)?                                    # any other preceding param (like /?s=tuff&v=xxxx)\n                             v=\n                         )\n                     )?                                                   # optional -> youtube.com/xxxx is OK\n                 )?                                                       # all until now is optional -> you can pass the naked ID\n                 ([0-9A-Za-z_-]+)                                         # here is it! the YouTube video ID\n                 (?(1).+)?                                                # if we found the ID, everything can follow\n                 $'
    mobj = re.match(gecerli_url, url, re.VERBOSE)
    video_id = mobj.group(2)
    html = get_url(url)
    html = html.replace('\\','')
    qualitylist = []
    videolist = []
    try:
        if 'm3u8' in html:
            link = re.findall('"(http[^"]+m3u8)"', html, re.IGNORECASE)[0]
            page = get_url(link)
            url_main = '/'.join(link.split('/')[:-1]) + '/'
            page1 = get_url(url_main)
            qualitylist = re.findall(',RESOLUTION=.*?x([0-9]+)', page1)
            videolist= re.findall('(https.*?m3u8)', page1)
            return videolist[-1:][0]

        else:
            info_url = 'https://www.youtube.com/watch?v=%s' % video_id
            infopage = get_url(info_url)
            urlpage = urllib.unquote(str(infopage))
            y = infopage.split('\\"streamingData\\":',2)[1]
            y = '\\"streamingData\\":' + y
            y = y.split('\\"adaptiveFormats\\"',2)[0]
            y = "{" + y[:-1] + "}}"
            y= y.replace('\\','').replace('u0026','&').replace("codecs=", "codecs=\\").replace("\"\"", "\\\"\"")
            json_data = json.loads(y)
            streams = json_data["streamingData"]["formats"]

            for stream in streams:
                videolist.append(stream["url"])
                qualitylist.append(stream["qualityLabel"])
            dialog = xbmcgui.Dialog()
            ret = dialog.select('kalite secin...',qualitylist)
            if ret > -1:
                return videolist[ret]
            else:
                return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def uptostream(url):
    video_tulpe =[]
    film_quality =[]
    request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
    html = urllib2.urlopen(request).read()
    base = re.findall("window\.sources = JSON\.parse\(atob\('(.*?)'",html)
    acik_base = decode_base64(base[0])
    try:
        for i in re.finditer('"src":"([^"]+)","type":"[^"]+","label":"([^"]+)"', acik_base):
            film_quality.append(i.group(2))
            video_tulpe.append(i.group(1).replace('\\', ''))
    except:
        for i in re.finditer('source src=[\'|"](.*?)[\'|"].*?data-res=[\'|"](.*?)[\'|"]', acik_base):
            film_quality.append(i.group(2))
            video_tulpe.append('http:' + i.group(1))
    if not film_quality:
        showMessage("[COLOR blue][B]seyirTURK[/B][/COLOR]","[COLOR blue][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    else:
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite secin...',film_quality)
        if ret > -1:
            return video_tulpe[ret]
        else:
            return 'yoks'
        
    
        

def afaki(url):
    headers = {'User-agent' : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    try:
        get = get_url('https://www.afaki.tk/a91f60fd-9664-4c79-b7e5-a038d1ef2ea7')
    except:
        pass
    try:
        req = urllib2.Request(url,None,headers)
        response = urllib2.urlopen(req)
        html = response.read()
        response.close()
        hash, id = re.findall('watch\("(.*?)","([^"]+)"', html, re.IGNORECASE)[0]
        data = urllib.urlencode({'hash': hash, 'id': id, 'e': '03'})
        req = urllib2.Request(url, data, headers)
        response = urllib2.urlopen(req)
        link = response.read()
        link1 = link [::-1]
        son_url1 = decode_base64(link1)
        Header = '#User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'
        son_url = son_url1 + Header
        return son_url
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def canlitvlive(url):
    req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0', 'Referer': url})
    response = urllib2.urlopen(req)
    html = response.read()
    response.close()
    link = re.findall(',file:"(.*?)"', html)
    Header = '#Referer='+url+'&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
    son = link[0]
    return son + Header
                
def closeload(url):
    try:
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0', 'Referer': url})
        response = urllib2.urlopen(req)
        html = response.read()
        response.close()
        Header = '#Referer='+url+'&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
        link = re.findall('"contentUrl": "([^"]+)"', html)
        son = link[0] + Header
        return son
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def vidmoly(url):
    try:
        videolist = []
        videolist1 = []
        qualitylist = []
        if "flmplayer" in url:
           req = urllib2.Request(url, headers={ 'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0' })
           html = urllib2.urlopen(req)
           html1 = html.read()
           content = html1
           url = html.geturl()
        else:
           url =  url.replace("http:","")
           url =  url.replace("https:","")
           url= 'https:' + url
           content = get_url(url)
        referer = '#User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0&Referer=https://vidmoly.to'
        m3u8link = re.findall('([^"]+\.m3u8)',content)
        videolist = re.findall('([^"]+\.mp4)',content)
        qualitylist = re.findall(',label:"(.*?)"',content)
        if qualitylist :
           for i in videolist:
               videolist1.append(i + referer)
        else:
           videolist1.append(videolist[0] + referer)
           qualitylist.append('mp4')
        try:
           videolist1.append(m3u8link[0] + referer)
           qualitylist.append('m3u8')
        except:
           pass
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist1[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def okru(url):
    try:
        videolist = []
        qualitylist = []
        url =  url.replace("http:","")
        url =  url.replace("https:","")
        url= 'https:' + url
        id1 = re.findall('https?://(?:www.)?(?:odnoklassniki|ok).ru/(?:videoembed/|dk\\?cmd=videoPlayerMetadata&mid=)(\\d+)', url)[0]
        nurl = 'https://ok.ru/videoembed/' + id1
        html = get_url(nurl)
        data = re.findall('''data-options=['"]([^'^"]+?)['"]''', html)[0]
        data = data.replace('\\', '').replace('&quot;', '').replace('u0026', '&')
        hata = re.findall('error":"([^"]+)', data)
        if hata:
            showMessage("[COLOR blue][B]seyirTURK[/B][/COLOR]","[COLOR blue][B]Film Bulunamadi[/B][/COLOR]")
            return 'yoks'
        else:
            qualitylist = re.findall('{name:(\\w+),url:.*?}', data)
            videolist = re.findall('{name:\\w+,url:(.*?),seekSchema', data)
            dialog = xbmcgui.Dialog()
            ret = dialog.select('kalite seçin...',qualitylist)
            if ret > -1:
                return videolist[ret]
            else:
                return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def filmmodu(url):
    try:
        html = get_url(url)
        videolist = re.findall('"src":"(.*?)"',html)
        qualitylist = re.findall('"label":"(.*?)"',html)
        try:
            subtitle = re.findall('"subtitle":"(.*?)"',html)[0]
            subtitle1 = 'https://www.filmmodu.org' + subtitle
        except:
            subtitle1 = ''
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return [videolist[ret],[subtitle1]]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def mailru(url):
    try:
        videolist = []
        qualitylist = []
        code = get_html(url)
        meta = re.findall('(?:metadataUrl|metaUrl)":.*?(//my[^"]+)', code)
        if meta:
            url2 = 'https:%s?ver=0.2.123' % meta[0]
            page = get_html(url2)
            key = re.findall('video_key[^;]+', page)
            if key:
                for match in re.finditer('url":"(//cdn[^"]+).+?(\\d+p)', page):
                    videolist.append('http:' + match.group(1) + '#User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0&Cookie=' + key[0])
                    qualitylist.append(match.group(2))
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except:
        showMessage("[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def fembed(url):
    try:
        videolist = []
        qualitylist = []
        try:
            if 'vcdn' in url:
                url= url.replace('vcdn.io','feurl.com')
        except:
            pass
        url = url.replace('/v/','/api/source/')
        dt = re.findall('(?:www.fembed.net|fembed.net|feurl.com)', url, re.IGNORECASE)[0]
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
            'Referer': url}
        data = "r=&d="+dt
        req = urllib2.Request(url, data , headers)
        response = urllib2.urlopen(req)
        html = response.read()
        html = html.replace('\\','')
        for match in re.finditer('"file":"([^"]+)","label":"([^"]+)"', html):
            qualitylist.append(match.group(2))
            videolist.append(match.group(1))
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def imdb(url):
    try:
        videolist = []
        qualitylist = []
        a= get_url(url)
        re1 = re.findall('"embedUrl":.*?"(.*?)"',a)[0]
        url2 = 'https://www.imdb.com' + re1.replace('video/imdb', 'videoembed')
        b = get_url(url2)
        for match in re.finditer('"videoUrl":"(.*?)"},{"definition":"(.*?)"', b):
            qualitylist.append(match.group(2))
            videolist.append(match.group(1).replace('\u002F','/'))
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def s1cdn(url):
    try:
        page = get_url(url)
        base = re.findall('"#2(.*?)"',page)
        return decode_base64(re.sub('(//.*?=)','',base[0]))
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def show(url):
    try:
        if not 'canli-yayin' in url and not 'canliyayin' in url:
            videolist =[]
            qualitylist = []
            page = get_url(url)
            a = re.findall("data-ht='(.*?)'",page)[0].replace("'",'"')
            aa = re.findall('"name":"(.*?)","file":"(.*?)"',a)[:4]
            for i in aa:
                videolist.append(i[1].replace('\\', ""))
                qualitylist.append(i[0])
            dialog = xbmcgui.Dialog()
            ret = dialog.select('kalite seçin...',qualitylist)
            if ret > -1:
                return videolist[ret]
            else:
                return 'yoks'
        else:
            page =get_url(url)
            canli_m3u8 = re.findall('ht_stream_m3u8":"(.*?)"', page)[0].replace('\/','/')
            return canli_m3u8
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def yjco(url):
    try:
        videolist =[]
        qualitylist = []
        page = get_url(url)
        a = re.findall('"file".*?:.*?"(.*?)".*?,.*?"label".*?:.*?"(.*?)"',page)
        for i in a:
            qualitylist.append(i[1])
            videolist.append(i[0])
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def foxplay(url):
    try:
        if not 'canli-yayin' in url:
            a = get_url(url)
            b = re.findall("videoSrc.*?:.*?'(.*?)'", a)
            return b[0]
        else:
            page =get_url(url)
            canli_m3u8 = re.findall("videoSrc\s*:\s*'(.*?)'", page)[0]
            return canli_m3u8
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def startv(url):
    try:
        if 'canli-yayin' in url:
            page = get_url(url)
            link = re.findall('src: "(.*?)"',page)
            return "https:" + link[0]
        else:
            a = get_url(url)
            c = re.findall('"videoUrl".*?:.*?"(.*?)"',a)
            d = get_url(c[0])
            b = json.loads(d)
            return b["data"]["flavors"]["hls"]
            return b[0]
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def atv(url):
    try:
        if 'atv.json' in url:
            page = get_url(url)
            link = re.findall('"hlsmanifest"\s*:\s*"(.*?)"',page)
            page1 = get_url(link[0])
            labels_links = re.findall('RESOLUTION=(.*?)x.*?\n(http.*?)\n',page1,re.DOTALL)
            return labels_links[1][1]
        else:
            headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.04',
                        'Referer':'http://www.atv.com.tr/'}
            req44 = urllib2.Request(url, None, headers)
            response = urllib2.urlopen(req44)
            data44 = response.read()
            website_id = re.findall('data-videoid="(.*?)".*?data-websiteid="(.*?)"',data44)
            url44 = 'https://videojs.tmgrup.com.tr/getvideo/' + website_id[0][1] + '/' + website_id[0][0]
            req = urllib2.Request(url44, None, headers)
            response = urllib2.urlopen(req)
            data = response.read()
            url2, url1 = re.findall('"VideoUrl":"([^"]+)".*?"VideoSmilUrl":"([^"]+)"', data, re.IGNORECASE)[0]
            host = 'https://securevideotoken.tmgrup.com.tr/webtv/secure?url=' + url1 + '&url2=' + url2
            req = urllib2.Request(host, None, headers)
            response = urllib2.urlopen(req)
            data2 = response.read()
            qualitylist =["m3u8","mp4"]
            videolist = re.findall('.*?Url":"(.*?)"', data2, re.IGNORECASE)
            dialog = xbmcgui.Dialog()
            ret = dialog.select('kalite seçin...',qualitylist)
            if ret > -1:
                return videolist[ret]
            else:
                return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def dailymotion(url):
    try:
        if not 'embed' in url:
            url = url.replace('video','embed/video')
        page = get_url(url)
        link = re.findall('mpegURL","url":"(.*?)"',page)
        ff = get_url (link[0].replace('\\/','/'))
        try:
            d = re.findall('EXT.*?NAME="720"\\n(.*?)\\n',ff)[0]
        except:
            d = re.findall('EXT.*?NAME="480"\\n(.*?)\\n',ff)[0]
        return d
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def fileru(url):
    try:
        videolist = []
        qualitylist = []
        url = url.replace('https:', '').replace('http:', '')
        url = 'http:' + url
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0', 'Referer': 'https://dizilla.com'})
        response = urllib2.urlopen(req)
        html = response.read()
        source_json = re.findall("getJSON\('(.*?)'", html)[0]
        source_link = 'http://fileru.net/' + source_json
        json_page = get_url(source_link)
        json_now = json.loads(json_page)
        for source in json_now["sources"]:
            qualitylist.append(source["label"])
            videolist.append(source["file"])
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def plus(url):
    try:
        videolist = []
        qualitylist = []
        url = url.replace('https:', '').replace('http:', '')
        url = 'http://dizipub.net' + url
        html = get_url(url)
        google_url = re.findall('src="(.*?)"',html)[0]
        google_id = re.findall('d/(.*?)/',google_url)[0]
        url = 'http://drive.google.com/file/d/%s/view' % google_id 
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0', 'Referer': url})
        response = urllib2.urlopen(req)
        sHtmlContent = response.read()
        Headers = response.headers
        response.close()
        c = Headers['Set-Cookie']
        c2 = re.findall('(?:^|,) *([^;,]+?)=([^;,\/]+?);',c)
        if c2:
            cookies = ''
            for cook in c2:
                cookies = cookies + cook[0] + '=' + cook[1] + ';'
        links_parts = re.findall('"fmt_stream_map","(.*?)"', sHtmlContent.decode('unicode-escape'))[0]
        links_part = re.findall('\\|(.*?)(?:,|$)', links_parts)
        film_quality = []
        for link_part in links_part:
            if link_part.encode('utf_8').find('itag=18') > -1:
                video_link = (link_part + "#User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0&Referer=https://youtube.googleapis.com/" + "&Cookie=" + cookies).encode('utf_8')
                videolist.append(video_link)
                qualitylist.append('360p')
            if link_part.encode('utf_8').find('itag=22') > -1:
                video_link = (link_part + "#User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0&Referer=https://youtube.googleapis.com/" + "&Cookie=" + cookies).encode('utf_8')
                videolist.append(video_link)
                qualitylist.append('720p')
            if link_part.encode('utf_8').find('itag=37') > -1:
                video_link = (link_part + "#User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0&Referer=https://youtube.googleapis.com/" + "&Cookie=" + cookies).encode('utf_8')
                videolist.append(video_link)
                qualitylist.append('1080p')
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def supervideo(url):
    try:
        content = get_url(url)
        content = re.findall('<script type=\'text/javascript\'>eval(.*?)</script>', content, re.DOTALL)
        content = content[0].split('|')
        content = content[1:-2]
        file_index = content.index("file")
        main_url = "https://" + content[file_index + 3] + "." + content[file_index + 2] + "." + content[file_index + 1] + "/"
        hls_index = content.index("hls")
        urlset_index = content.index("urlset")
        diff = hls_index - urlset_index
        hls = ""
        for x in range(1, diff):
            hls = hls + content[hls_index-x]+ ","
        hls = 'hls/' + hls + '.' + content[urlset_index] + '/master.m3u8'
        video= main_url + hls
        """mp4s = {'hls': main_url+hls}
        x = -12
        while content[x] != 'image':
            mp4s[content[x-1]] = main_url + content[x] + "/v.mp4"
            x -= 2
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...', mp4s.keys())
        return mp4s.values()[ret]"""
        return video
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
     
def kanald(url):
    try:
        if 'kanald.json' in url:
            page = get_url(url)
            link = re.findall('"hlsmanifest"\s*:\s*"(.*?)"',page)
            page1 = get_url(link[0])
            labels_links = re.findall('RESOLUTION=(.*?)x.*?\n(http.*?)\n',page1,re.DOTALL)
            return labels_links[1][1]
        else:
            html = get_url(url)
            embed_url = re.findall('"embedUrl":"(.*?)"',html)[0]
            page = get_url(embed_url)
            link = re.findall('"contentUrl":"(.*?)"',page)[0] + '#User-Agent=Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36'
            return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def dizibox(url):
    try:
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'Referer': 'dizibox.pw'})
        html = urllib2.urlopen(req).read()
        if 'mecnun.php' in url:
            link = re.findall('file:"(.*?)"', html)[0]
        elif 'moly.php' in url:
            page = urllib.unquote(html)
            page_atob = re.findall('atob\(unescape\("(.*?)"',page)[0]
            page = decode_base64(page_atob)
            link = re.findall('iframe src="(.*?)"',page)[0]
        elif 'indi.php' in url:
            link = re.findall('file:"(.*?)"',html)[0]
        elif 'haydi.php' in url:
            link = re.findall('frame src="(.*?)"',html)[0]
        elif 'king.php' in url:
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi bu linki desteklemiyor![/B][/COLOR]",4000)
            link1 = re.findall('frame src="(.*?)"',html)[0]
            link = link1 + '/sheila#User-Agent=Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0&Referer=https://dbx.molystream.com'
            link = 'yoks'
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def dizilabapi(url):
    link = url + '#User-Agent=Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36&Referer=dizilab.pw'
    return link

def chefkoch24(url):
    try:
        videolist =[]
        qualitylist = []
        page = get_url(url)
        a = re.findall('source\s*src="(.*?)"\s*type=\'.*?\'\s*label\s*=\'(.*?)\'',page)
        for i in a:
            qualitylist.append(i[1])
            videolist.append(i[0])
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def haberturk(url):
    try:
        page = get_url(url)
        link = re.findall('ht_stream_m3u8":"(.*?)"',page)
        return link[0].replace('\/','/')
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def dha(url):
    try:
        page = get_url(url)
        link = re.findall("video.src\s*=\s*'(.*?)'",page)
        return link[0].replace('\/','/')
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def tv8(url):
    try:
        page = get_url(url)
        link = re.findall('file\s*:\s*"(.*?)"',page)
        return link[0]
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def cnnteve2(url):
    try:
        page = get_url(url)
        link = re.findall('"contentUrl"\s*:\s*"(.*?)"',page)[0]
        if 'cnn' in url:
            ref_use = '#Referer=https://www.cnnturk.com/canli-yayin&User-Agent=Mozilla'
        elif 'teve2' in url:
            ref_use = '#Referer=https://www.teve2.com.tr/canli-yayin&User-Agent=Mozilla' 
        return link + ref_use
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    

def tlc(url):
    try: 
        page = get_url(url)
        link = re.findall('liveUrl\s*=\s*"(.*?)"',page)[0]
        page = get_url(link)
        link1 = re.findall(',RESOLUTION=1280x720\n(.*?m3u8)', page)[0]
        if 'dmax'in url:
            link = 'https://jviqfbc2.rocketcdn.com/dmax.smil/' + link1
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def ntv(url):
    try: 
        page = get_url(url)
        link = re.findall('srcLive\s*=\s*"(.*?)"',page)
        return link[0]
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def kanal7(url):
    try: 
        page = get_url(url)
        link = re.findall("video-source'\s*,\s*'(.*?)'",page)[0]
        return link + '#Referer=https://www.kanal7.com/canli-izle&User-Agent=Mozilla'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def halktv(url):
    try: 
        page = get_url(url)
        link = re.findall('<iframe.*?src="(.*?)"',page)[0]
        return link.replace('/embed/','/watch?v=')
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def kralmuzik(url):
    try: 
        page = get_url(url)
        vid_id = re.findall("youtube.init\('(.*?)'",page)[0]
        return 'https://www.youtube.com/watch?v=' + vid_id
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def numberone(url):
    try: 
        page = get_url(url)
        vid = re.findall('<iframe.*?src="(.*?)"',page)[0]
        return 'https:' + vid
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def brtk(url):
    try: 
        req = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5376e Safari/8536.25', 'Connection': 'Close'})
        page = urllib2.urlopen(req).read()
        if not 'bayrak' in url:
            link = re.findall('video_player.*?"><a href="(.*?)"', page)[0]
        elif 'bayrak' in url:
            link = re.findall('video_player mobile"><a href="(.*?);', page)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def ahaber(url):
    try: 
        a = 'https://securevideotoken.tmgrup.com.tr/webtv/secure?851521&url='
        if 'apara' in url:
            aa = 'http%3A%2F%2Ftrkvz-live.ercdn.net%2Faparahd%2Faparahd.m3u8'
        elif 'ahaber' in url:
            aa = 'https%3A%2F%2Ftrkvz-live.ercdn.net%2Fahaberhd%2Fahaberhd.m3u8'
        elif 'anews' in url:
            aa = 'http%3A%2F%2Ftrkvz-live.ercdn.net%2Fanewshd%2Fanewshd.m3u8'
        elif 'aspor' in url:
            aa = 'https%3A%2F%2Ftrkvz-live.ercdn.net%2Fasporhd%2Fasporhd.m3u8'
        elif 'a2tv' in url:
            aa = 'https%3A%2F%2Ftrkvz-live.ercdn.net%2Fa2tv%2Fa2tv.m3u8'
        user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
        referer = url
        url = a + aa
        req = urllib2.Request(url, None, {'User-Agent': user_agent, 'Referer': referer})
        content = urllib2.urlopen(req).read()
        link = re.findall('"Url":"(.*?)"', content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def tv360(url):
    try: 
        content = get_url(url)
        link = re.findall("hls.loadSource\('(.*?)'", content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def ucankus(url):
    try: 
        content = get_url(url)
        link = re.findall('<source\s*src="(.*?)"', content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
 
def dreamturk(url):
    try: 
        content = get_url(url)
        vid_id = re.findall("var\s*_itemId\s*=\s*'(.*?)'", content)[0]
        url2 = 'https://www.dreamturk.com.tr/actions/content/media/' + vid_id
        content = get_url(url2)
        linkos = json.loads(content)
        link = linkos["Media"]["Link"]["ServiceUrl"] + linkos["Media"]["Link"]["SecurePath"]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
 
def beyaztv(url):
    try: 
        content = get_url(url)
        link= re.findall('"embedUrl"\s*:\s*"(.*?)"', content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
 
def tvem(url):
    try: 
        content = get_url(url)
        url2 = re.findall('<div class="live-area">\s*\n.*?<script src="(.*?)"></script>', content)[0]
        url2 = 'http:' + url2
        content = get_url(url2)
        url3 = re.findall('yayincomtr4="(.*?)"', content)[0]
        content = get_url('http:' + url3)
        link = re.findall('#EXT-X-STREAM-INF.*?RESOLUTION=720x486\n(.*?)$', content)[0]
        link = 'http://cdn-TVEM.yayin.com.tr/TVEM/TVEM/' + link
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def ulusal(url):
    try: 
        content = get_url(url)
        content = urllib.unquote(content)
        link = re.findall('<iframe.*?src="(.*?)"',content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def kanalb(url):
    try: 
        content = get_url(url)
        link = re.findall('file\s*:\s*"(.*?)"',content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def tvnet(url):
    try: 
        content = get_url(url)
        link = re.findall('<source\s*src="(.*?)"',content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def ulketv(url):
    try: 
        content = get_url(url)
        link = re.findall("'video-source','(.*?)'",content)[0]
        return link + '#Referer=' + url + '&User-Agent=Mozilla'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def ekoturk(url):
    try: 
        content = get_url(url)
        link = re.findall('<iframe.*?src="(.*?)\?',content)[0]
        return link.replace('/embed/','/watch?v=')
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def womantv(url):
    try:
        url = 'https://appie.vidpanel.com/wmtv/video/live'
        content = get_url(url)
        content = json.loads(content)
        link = content["video"]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def sportstv(url):
    try:
        url = 'http://avrupaoyunlari.sportstv.com.tr:8188/a2srv-client/anonymous'
        content = get_url(url)
        content = json.loads(content)
        data = content["data"]
        url2 = 'http://avrupaoyunlari.sportstv.com.tr:8188/cms-btv-client/getactivechannelsofchannel/1'
        req = urllib2.Request(url2, None, {'User-Agent': 'Mozilla', 'Authorization': data})
        content = urllib2.urlopen(req).read()
        content = json.loads(content)
        link = content["data"][0]["url"]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def tjk(url):
    try:
        url = 'https://www.tjk.org/TR/YarisSever/Static/Canli'
        content = get_url(url)
        link =re.findall("hls\s*:\s*'(.*?)'", content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'

def yaban(url):
    try:
        content = get_url(url)
        url2 =re.findall('<iframe.*?src="(.*?)"', content)[0]
        if not 'http' in url2:
            url2 = 'http:' + url2
        content = get_url(url2)
        link = re.findall('file\s*:\s*"(.*?)"', content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'
        
def videobin(url):
    try: 
        videolist = []
        qualitylist = []
        page = get_url(url)
        links = re.findall('sources:\s*\["(.*?)","(.*?)"', page)
        for link in links[0]:
            if 'm3u8' in link:
                qualitylist.append('m3u8')
                videolist.append(link)
            if 'mp4' in link:
                qualitylist.append('mp4')
                videolist.append(link)
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def gounlimited(url):
    try: 
        page = get_url(url)
        link_code = re.findall("type\|(.*?)'.split", page)[0]
        link = link_code.split("|")
        mp4 = "https://" + link[1]+ ".gounlimited.to/" + link[0] + "/v.mp4"
        return mp4
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def saruch(url):
    try: 
        vid_id = url.split('/')
        url = 'https://api.saruch.co/videos/' + vid_id[4] + '/stream?referrer=' +urllib.quote(url)
        page = get_url(url)
        link = re.findall('"file":"(.*?)"', page)[0].replace('\/','/')
        de, en = re.findall('"de":"(.*?)","en":"(.*?)"', page)[0]
        link = link + '?de=' + de + '&en=' + en + '&.m3u8'
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi bu linki desteklemiyor![/B][/COLOR]",4000)
        link = 'yoks'
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def yabancidizi(url):
    try:
        user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
        referer = 'https://yabancidizi.vip/dizi'
        req = urllib2.Request(url, None, {'User-Agent': user_agent, 'Referer': referer})
        page= urllib2.urlopen(req).read()
        if 'api/drive' in url:
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi bu linki desteklemiyor![/B][/COLOR]",4000)
            link = re.findall('iframe src="(.*?)"', page)[0].replace('ydx', 'dbx') + '/sheila'
            link = 'yoks'
        elif 'api/cf' in url or 'api/indi' in url:
            link = re.findall('file:"(.*?)"', page)[0]
        elif 'api/moly' in url or 'api/ruplay' in url or 'api/saru' in url or 'api/goo' in url or 'api/superv' in url:  #/gounlimited.to ikinci kez girecek
            link = re.findall('iframe src="(.*?)"', page)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
        
def streamtheworld(url):
    try:
        page = get_url(url)
        ip = re.findall('<ip>(.*?)</ip>',page)[0]
        radyo = re.findall('<mount>(.*?)</mount>', page)[0]
        link = 'https://' + ip + '/' + radyo +'.mp3'
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'            
        
def chaturbate(url):
    try:
        content = get_url(url)
        content = re.findall('hls_source\\\\u0022:\s*\\\\u0022(.*?)\\\\u0022', content)[0].replace('\u002D','-')
        content1 = content.rsplit('/',1)[:-1][0]
        page = get_url(content)
        try:
            link = re.findall('RESOLUTION=1280x720\n(.*?)$', page)[0]
        except:
            link = re.findall('RESOLUTION=1280x720\n(.*?m3u8)', page)[0]
        link = content1 + '/' + link
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'            
        
def hdtvler(url):
    try:
        url1 = 'https://www.hdtvler.tv/Tv/TVShow'
        page = get_url(url)
        values = re.findall('const data = (.*?);',page, re.DOTALL)[0].replace(' ','').replace('\n','').replace("'",'"').replace(':','":').replace('{', '{"').replace(',', ',"').replace('\r','')
        user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
        referer = 'https://www.hdtvler.tv/show-tv-canli-hd-yayin-izle/'
        xreq = 'XMLHttpRequest'
        headers = {'User-Agent': user_agent, 'Referer': referer, 'X-Requested-With': xreq, 'Content-Type': 'application/json'}
        req = urllib2.Request(url1, json.dumps(json.loads(values)), headers)
        response = urllib2.urlopen(req)
        the_page = response.read()
        js = json.loads(the_page)
        try:
            content = re.findall("file:'(.*?)'", js["result"]["playerBodyEnd"])[0]
        except:
            content = re.findall('contentURL"\s*:\s*(.*?)"', js["result"]["playerBodyEnd"])[0]
        return content
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]IPTV Bulunamadi[/B][/COLOR]")
        return 'yoks'            
def canliradyolar(url):
    try:
        content = get_url(url)
        url = re.findall('iframe\s*src="(.*?)"\s*name=', content)[0]
        content = get_url(url)
        link = re.findall('"m4a"\s*:\s*"(.*?);',content)[0]
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Radyo Bulunamadi[/B][/COLOR]")
        return 'yoks'  
def ashemale(url):
    try: 
        videolist = []
        qualitylist = []
        page = get_url(url)
        links_labels = re.findall('"src":"(.*?)","desc":"(.*?)",', page)
        for link in links_labels:
            qualitylist.append(link[1])
            videolist.append(link[0].replace("\\/","/"))
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
    
def pornhub(url):
    try: 
        videolist = []
        qualitylist = []
        html = get_url(url)
        vars = re.findall('var\s+(.+?)\s*=\s*(.+?);', html)
        links = re.findall('quality_(\d+)p\s*=\s*(.+?);', html)
        if links:
            sources = []
            for source in links:
                try:
                    link = [i.strip() for i in source[1].split('+')]
                    link = [i for i in link if i.startswith('*/')]
                    link = [re.sub('^\*/', '', i) for i in link]
                    link = [(i, [x[1] for x in vars if x[0] == i]) for i in link]
                    link = [i[1][0] if i[1] else i[0] for i in link]
                    link = ''.join(link)
                    link = re.sub('\s|\+|\'|\"', '', link)
                    videolist.append(link)
                    qualitylist.append(source[0])
                except:
                    continue
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'

def clipwatching(url):
    try:
        page = get_url(url)
        link = re.findall('{src: "(.*?)"',page)[0]
        link = link + '#Referer=http://streamingporn.xyz'
        return link
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Radyo Bulunamadi[/B][/COLOR]")
        return 'yoks'  
def xvideos(url):
    try: 
        videolist = []
        qualitylist = []
        page = get_url(url)
        links = re.findall(r'''setVideo(?:Url)?(?P<label>(?:HLS|High|Low))\(['"](?P<url>[^"']+)''',page)
        for link in links:
            qualitylist.append(link[0])
            videolist.append(link[1])
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite seçin...',qualitylist)
        if ret > -1:
            return videolist[ret]
        else:
            return 'yoks'
    except urllib2.URLError, e:
        if  'ssl.c:510: error' in str(e.reason):
            showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR red][B]Kodi Sürümünüz bu linki desteklemiyor![/B][/COLOR]",5000)
        return 'yoks'
    except:
        showMessage("[COLOR orange][B]seyirTURK[/B][/COLOR]","[COLOR orange][B]Film Bulunamadi[/B][/COLOR]")
        return 'yoks'
